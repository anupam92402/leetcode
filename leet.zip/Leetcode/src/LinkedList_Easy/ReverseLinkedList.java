package LinkedList_Easy;

//206

public class ReverseLinkedList {

	public class ListNode {
		int val;
		ListNode next;

		ListNode() {
		}

		ListNode(int val) {
			this.val = val;
		}

		ListNode(int val, ListNode next) {
			this.val = val;
			this.next = next;
		}
	}

	public ListNode reverseList(ListNode root) {
		if (root == null || root.next == null) {
			return root;
		}
		ListNode prev = root, curr = root.next;
		prev.next = null;
		while (curr != null) {
			prev = curr;
			curr = curr.next;

			prev.next = root;
			root = prev;
		}
		return root;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
