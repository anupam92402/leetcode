package DP_Medium;

//62

public class UniquePaths {

	public static int uniquePaths(int m, int n) {
		int[][] grid = new int[m][n];
		for (int i = m - 1; i >= 0; i--) {
			for (int j = n - 1; j >= 0; j--) {
				if (i == grid.length - 1 && j == grid[0].length - 1) {
					grid[i][j] = 1;
				} else if (i == grid.length - 1) {
					grid[i][j] = 1;
				} else if (j == grid[0].length - 1) {
					grid[i][j] = 1;
				} else {
					grid[i][j] = grid[i + 1][j] + grid[i][j + 1];
				}
			}
		}
		return grid[0][0];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m = 3;
		int n = 7;
		System.out.println(uniquePaths(m, n));
	}

}
