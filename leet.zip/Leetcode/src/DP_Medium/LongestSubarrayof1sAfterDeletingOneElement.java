package DP_Medium;

//1493

public class LongestSubarrayof1sAfterDeletingOneElement {

	public static int longestSubarray1(int[] nums) {

		int max = 0;
		for (int i = 0; i < nums.length; i++) {
			int cnt = 0;
			int ls = 0;
			if (nums[i] == 0) {
				continue;
			} else if (i > 0 && nums[i] == nums[i - 1]) {
				continue;
			} else {
				int j = i + 1;
				ls = 1;
				while (j < nums.length) {
					if (nums[j] == 0) {
						if (cnt == 1) {
							break;
						}
						ls--;
						cnt++;
					}
					j++;
					ls++;
				}
				max = Math.max(max, ls);
			}
		}
		return max == nums.length ? max - 1 : max;
	}

	public static int longestSubarray2(int[] nums) {
		int res = 0;
		for (int l = 0, r = 0, zeros = 1; r < nums.length; ++r) {
			if (nums[r] == 0)
				zeros--;

			while (zeros < 0) {
				if (nums[l++] == 0)
					zeros++;
			}

			res = Math.max(res, r - l);
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 1, 1, 1 };
		System.out.println(longestSubarray2(nums));
	}

}
