package Backtracking_Medium;

import java.util.LinkedList;
import java.util.List;

//78

public class Subsets {

	public static List<List<Integer>> subsets(int[] nums) {
		List<List<Integer>> subset = new LinkedList<>();
		subsets(nums, 0, subset, new LinkedList<>());
		return subset;
	}

	private static void subsets(int[] nums, int vidx, List<List<Integer>> subset, LinkedList<Integer> temp) {

		subset.add(new LinkedList<>(temp));

		for (int i = vidx; i < nums.length; i++) {
			temp.add(nums[i]);
			subsets(nums, i + 1, subset, temp);
			temp.remove(temp.size() - 1);
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 1, 2, 3 };
		System.out.println(subsets(nums));
	}

}
