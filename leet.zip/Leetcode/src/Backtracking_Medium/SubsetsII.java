package Backtracking_Medium;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

//90

public class SubsetsII {

	public static List<List<Integer>> subsetsWithDup1(int[] nums) {
		Arrays.sort(nums);
		List<List<Integer>> subset = new LinkedList<>();
		subsetsWithDup1(nums, 0, subset, new LinkedList<>());
		return subset;
	}

	private static void subsetsWithDup1(int[] nums, int vidx, List<List<Integer>> subset, LinkedList<Integer> temp) {

		subset.add(new LinkedList<>(temp));

		for (int i = vidx; i < nums.length; i++) {

			if (i > vidx && nums[i] == nums[i - 1]) {
				continue;
			}

			temp.add(nums[i]);
			subsetsWithDup1(nums, i + 1, subset, temp);
			temp.remove(temp.size() - 1);
		}

	}

	public static List<List<Integer>> subsetsWithDup2(int[] nums) {

		Arrays.sort(nums);
		List<List<Integer>> result = new ArrayList<>();
		List<Integer> subset = new ArrayList<>();

		result.add(subset);
		int start = 0;
		int len = 0;
		for (int j = 0; j < nums.length; j++) {
			start = 0;
			if (j > 0 && nums[j] == nums[j - 1]) {
				start = len;
			}
			len = result.size();
			for (int i = start; i < len; i++) {
				subset = new ArrayList<>(result.get(i));
				subset.add(nums[j]);
				result.add(subset);
			}
		}

		return result;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 1, 2, 2 };
		System.out.println(subsetsWithDup2(nums));
	}

}
