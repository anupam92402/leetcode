package Backtracking_Medium;

//79

public class WordSearch {

	public static boolean exist(char[][] board, String word) {
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[0].length; j++) {
				if (board[i][j] == word.charAt(0)) {
					if (exist(i, j, board, word, 0)) {
						return true;
					}
				}
			}
		}
		return false;
	}

	private static boolean exist(int i, int j, char[][] board, String word, int idx) {
		if (idx == word.length()) {
			return true;
		}
		if (i < 0 || j < 0 || i >= board.length || j >= board[0].length || board[i][j] == '0') {
			return false;
		}

		char ch = board[i][j];
		boolean ans = false;
		if (ch == word.charAt(idx)) {
			board[i][j] = '0';
			ans = ans || exist(i + 1, j, board, word, idx + 1);
			ans = ans || exist(i - 1, j, board, word, idx + 1);
			ans = ans || exist(i, j + 1, board, word, idx + 1);
			ans = ans || exist(i, j - 1, board, word, idx + 1);
			board[i][j] = ch;
		}
		return ans;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[][] board = { { 'A', 'B', 'C', 'E' }, { 'S', 'F', 'C', 'S' }, { 'A', 'D', 'E', 'E' } };
		String word = "ABCB";
		System.out.println(exist(board, word));
	}

}
