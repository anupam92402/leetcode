package Array_Medium;

//1395

public class CountNumberofTeams {

	public static int numTeams(int[] rating) {

		int teams = 0;

		for (int i = 0; i < rating.length; i++) {
			int[] lesser = new int[2]; // 0-left 1-right
			int[] greater = new int[2];// 0-left 1-right
			for (int j = 0; j < rating.length; j++) {
				if (i == j) {
					continue;
				}
				if (rating[i] <= rating[j]) {
					if (j > i) {
						greater[1]++;
					} else {
						greater[0]++;
					}
				} else {
					if (j > i) {
						lesser[1]++;
					} else {
						lesser[0]++;
					}
				}
			}
			teams += lesser[0] * greater[1] + lesser[1] * greater[0];
		}
		return teams;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] rating = { 2, 5, 3, 4, 1 };
		System.out.println(numTeams(rating));
	}

}
