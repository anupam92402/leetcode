package Array_Medium;

import java.util.LinkedList;
import java.util.List;

//54

public class SpiralMatrix {

	public static List<Integer> spiralOrder(int[][] matrix) {
		List<Integer> spiral = new LinkedList<>();
		int count = 1;
		int minrow = 0, maxrow = matrix.length - 1, mincol = 0, maxcol = matrix[0].length - 1;

		while (count <= matrix.length * matrix[0].length) {
			for (int col = mincol; col <= maxcol && count <= matrix.length * matrix[0].length; col++) {
				spiral.add(matrix[minrow][col]);
				count++;
			}
			minrow++;
			for (int row = minrow; row <= maxrow && count <= matrix.length * matrix[0].length; row++) {
				spiral.add(matrix[row][maxcol]);
				count++;
			}
			maxcol--;
			for (int col = maxcol; col >= mincol && count <= matrix.length * matrix[0].length; col--) {
				spiral.add(matrix[maxrow][col]);
				count++;
			}
			maxrow--;
			for (int row = maxrow; row >= minrow && count <= matrix.length * matrix[0].length; row--) {
				spiral.add(matrix[row][mincol]);
				count++;
			}
			mincol++;
		}
		return spiral;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] matrix = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		System.out.println(spiralOrder(matrix));
	}

}
