package Array_Medium;

//59

public class SpiralMatrixII {

	public static int[][] generateMatrix(int n) {
		int[][] matrix = new int[n][n];
		int count = 1;
		int minrow = 0, maxrow = matrix.length - 1, mincol = 0, maxcol = matrix[0].length - 1;

		while (count <= n * n) {
			for (int col = mincol; col <= maxcol && count <= n * n; col++) {
				matrix[minrow][col] = count;
				count++;
			}
			minrow++;
			for (int row = minrow; row <= maxrow && count <= n * n; row++) {
				matrix[row][maxcol] = count;
				count++;
			}
			maxcol--;
			for (int col = maxcol; col >= mincol && count <= n * n; col--) {
				matrix[maxrow][col] = count;
				count++;
			}
			maxrow--;
			for (int row = maxrow; row >= minrow && count <= n * n; row--) {
				matrix[row][mincol] = count;
				count++;
			}
			mincol++;
		}
		return matrix;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 3;
		int[][] matrix = generateMatrix(n);
		for (int[] mat : matrix) {
			for (int m : mat) {
				System.out.print(m + " ");
			}
			System.out.println();
		}
	}

}
