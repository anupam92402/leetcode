package Array_Medium;

import java.util.LinkedList;
import java.util.List;

//39

public class CombinationSum {

	public static List<List<Integer>> combinationSum(int[] candidates, int target) {
		List<List<Integer>> sum = new LinkedList<>();
		combinationSum(candidates, target, 0, new LinkedList<Integer>(), sum);
		return sum;
	}

	private static void combinationSum(int[] candidates, int target, int vidx, LinkedList<Integer> temp,
			List<List<Integer>> sum) {

		if (target == 0) {
			sum.add(new LinkedList<>(temp));
		}

		for (int i = vidx; i < candidates.length; i++) {
			if (target - candidates[i] >= 0) {
				temp.add(candidates[i]);
				combinationSum(candidates, target - candidates[i], i, temp, sum);
				temp.remove(temp.size() - 1);
			}
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] candidates = { 5, 3, 2, 7 };
		int target = 8;
		System.out.println(combinationSum(candidates, target));
	}

}
