package Array_Medium;

import java.util.LinkedList;
import java.util.List;

public class CombinationSumIII {

	public static List<List<Integer>> combinationSum3(int k, int n) {
		List<Integer> temp = new LinkedList<>();
		List<List<Integer>> sum = new LinkedList<>();
		combinationSum3(1, temp, sum, k, n);
		return sum;
	}

	private static void combinationSum3(int vidx, List<Integer> temp, List<List<Integer>> sum, int k, int n) {
		if (k == 0) {
			if (n == 0)
				sum.add(new LinkedList<>(temp));
			return;
		}
		for (int i = vidx; i < 10; i++) {
			if (n - i >= 0) {
				temp.add(i);
				combinationSum3(i + 1, temp, sum, k - 1, n - i);
				temp.remove(temp.size() - 1);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 7;
		int k = 3;
		System.out.println(combinationSum3(k, n));
	}

}
