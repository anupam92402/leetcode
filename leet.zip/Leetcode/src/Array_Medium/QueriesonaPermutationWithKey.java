package Array_Medium;

import java.util.ArrayList;

//1409

public class QueriesonaPermutationWithKey {

	public static int[] processQueries(int[] queries, int m) {
		ArrayList<Integer> permutation = new ArrayList<>();
		for (int i = 1; i <= m; i++) {
			permutation.add(i);
		}
		int[] res = new int[queries.length];
		for (int i = 0; i < queries.length; i++) {
			int idx = permutation.indexOf(queries[i]);
			permutation.add(0, permutation.remove(idx));
			res[i] = idx;
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] queries = { 3, 1, 2, 1 };
		int m = 5;
		int[] ans = processQueries(queries, m);
		for (int a : ans) {
			System.out.print(a + " ");

		}
	}

}
