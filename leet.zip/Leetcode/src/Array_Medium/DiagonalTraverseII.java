package Array_Medium;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

//1424

public class DiagonalTraverseII {

	public static int[] findDiagonalOrder1(List<List<Integer>> nums) {
		int n = 0, i = 0, maxKey = 0;
		Map<Integer, List<Integer>> map = new HashMap<>();
		for (int r = nums.size() - 1; r >= 0; --r) { // The values from the bottom rows are the starting values of the
														// diagonals.
			for (int c = 0; c < nums.get(r).size(); ++c) {
				map.putIfAbsent(r + c, new ArrayList<>());
				map.get(r + c).add(nums.get(r).get(c));
				maxKey = Math.max(maxKey, r + c);
				n++;
			}
		}
		int[] ans = new int[n];
		for (int key = 0; key <= maxKey; ++key) {
			List<Integer> value = map.get(key);
			if (value == null)
				continue;
			for (int v : value)
				ans[i++] = v;
		}
		return ans;
	}

	public static int[] findDiagonalOrder2(List<List<Integer>> nums) {
		if (nums == null || nums.isEmpty())
			return new int[0];
		int size = 0; // the total size in nums
		// new index = r + c, inside list: list of numbers whose index = r + c
		List<LinkedList<Integer>> diags = new ArrayList<>();
		for (int r = 0; r < nums.size(); r++) {
			List<Integer> row = nums.get(r);
			for (int c = 0; c < row.size(); c++) {
				int idx = r + c;
				if (idx == diags.size()) {
					diags.add(new LinkedList<>());
				}
				LinkedList<Integer> diag = diags.get(idx);
				diag.addFirst(row.get(c)); // add to the first position
				size++;
			}
		}
		int[] res = new int[size];
		int k = 0;
		for (List<Integer> diag : diags) {
			for (int num : diag) {
				res[k++] = num;
			}
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<List<Integer>> nums = new LinkedList<List<Integer>>();
		List<Integer> temp = new LinkedList<>();
		temp.add(1);
		temp.add(2);
		temp.add(3);
		temp.add(4);
		temp.add(5);
		nums.add(new LinkedList<>(temp));
		temp = new LinkedList<>();
		temp.add(6);
		temp.add(7);
		temp.add(8);
		temp.add(9);
		temp.add(10);
		nums.add(new LinkedList<>(temp));
		temp = new LinkedList<>();
		temp.add(11);
		temp.add(12);
		temp.add(13);
		nums.add(new LinkedList<>(temp));
		temp = new LinkedList<>();

		int[] ans = findDiagonalOrder2(nums);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
