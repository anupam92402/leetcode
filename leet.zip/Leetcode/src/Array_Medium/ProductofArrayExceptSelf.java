package Array_Medium;

//238

public class ProductofArrayExceptSelf {

	public static int[] productExceptSelf(int[] nums) {
		int[] product = new int[nums.length];
		int left = nums[0];
		product[0] = 1;
		for (int i = 1; i < nums.length; i++) {
			product[i] = 1;
			product[i] *= left;
			left *= nums[i];
		}

		int right = nums[nums.length - 1];
		for (int i = nums.length - 2; i >= 0; i--) {
			product[i] *= right;
			right *= nums[i];
		}
		return product;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { -1, 1, 0, -3, 3, 0 };
		int[] ans = productExceptSelf(nums);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
