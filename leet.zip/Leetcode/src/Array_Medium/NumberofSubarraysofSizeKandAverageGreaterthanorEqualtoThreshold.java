package Array_Medium;

//1343

public class NumberofSubarraysofSizeKandAverageGreaterthanorEqualtoThreshold {

	public static int numOfSubarrays(int[] arr, int k, int threshold) {
		int n = arr.length, count = 0;
		int[] prefixSum = new int[n + 1];
		for (int i = 0; i < n; ++i)
			prefixSum[i + 1] = prefixSum[i] + arr[i];
		for (int i = 0; i + k <= n; ++i)
			if (prefixSum[i + k] - prefixSum[i] >= k * threshold)
				++count;
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 2, 2, 2, 2, 5, 5, 5, 8 };
		int k = 3;
		int threshold = 4;
		System.out.println(numOfSubarrays(arr, k, threshold));
	}

}
