package Array_Medium;

import java.util.Arrays;

//1338

public class ReduceArraySizetoTheHalf {

	public static int minSetSize(int[] arr) {
		int[] freq = new int[100001];
		int size = 0, count = 0;
		for (int i = 0; i < arr.length; i++) {
			freq[arr[i]]++;
		}
		Arrays.sort(freq);
		for (int j = 100000; j >= 0; j--) {
			size = size + freq[j];
			count++;
			if (size >= arr.length / 2)
				return count;
		}
		return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 3, 3, 3, 3, 5, 5, 5, 2, 2, 7 };
		System.out.println(minSetSize(arr));
	}

}
