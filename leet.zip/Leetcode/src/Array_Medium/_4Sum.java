package Array_Medium;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

//18

public class _4Sum {

	public static List<List<Integer>> fourSum(int[] nums, int target) {
		List<List<Integer>> sum = new LinkedList<>();
		Arrays.sort(nums);
		for (int i = 0; i < nums.length - 3; i++) {
			if (i > 0 && nums[i] == nums[i - 1]) {
				continue;
			}
			for (int j = i + 1; j < nums.length - 2; j++) {
				if (j != i + 1 && nums[j] == nums[j - 1]) {
					continue;
				}
				fourSum(nums, target, i, j, sum);
			}
		}
		return sum;
	}

	private static void fourSum(int[] nums, int target, int i, int j, List<List<Integer>> sum) {
		// TODO Auto-generated method stub
		int num1 = nums[i], num2 = nums[j];
		int start = j + 1, end = nums.length - 1;
		while (start < end) {
			if (num1 + num2 + nums[start] + nums[end] > target) {
				end--;
			} else if (num1 + num2 + nums[start] + nums[end] < target) {
				start++;
			} else {
				List<Integer> temp = new LinkedList<>();
				temp.add(num1);
				temp.add(num2);
				temp.add(nums[start]);
				temp.add(nums[end]);
				sum.add(new LinkedList<>(temp));
				start++;
				end--;
				for (int k = start; k < nums.length; k++) {
					if (nums[k] != nums[k - 1]) {
						break;
					}
					start++;
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { -2, -1, -1, 1, 1, 2, 2 };
		int target = 0;
		System.out.println(fourSum(nums, target));
	}

}
