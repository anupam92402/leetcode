package Array_Medium;

import java.util.LinkedList;
import java.util.List;

//1222

public class QueensThatCanAttacktheKing {

	public static List<List<Integer>> queensAttacktheKing(int[][] queens, int[] king) {
		boolean[][] board = new boolean[8][8];
		for (int i = 0; i < queens.length; i++) {
			int row = queens[i][0];
			int col = queens[i][1];
			board[row][col] = true;
		}
		List<List<Integer>> attack = new LinkedList<>();
		check(king[0], king[1], attack, board, 0, 1);
		check(king[0], king[1], attack, board, 0, -1);
		check(king[0], king[1], attack, board, 1, 0);
		check(king[0], king[1], attack, board, -1, 0);
		check(king[0], king[1], attack, board, 1, 1);
		check(king[0], king[1], attack, board, 1, -1);
		check(king[0], king[1], attack, board, -1, 1);
		check(king[0], king[1], attack, board, -1, -1);
		return attack;
	}

	private static void check(int rows, int cols, List<List<Integer>> attack, boolean[][] board, int rowDiff,
			int colDiff) {

		while (rows >= 0 && rows < board.length && cols >= 0 && cols < board[0].length) {
			if (board[rows][cols]) {
				List<Integer> temp = new LinkedList<>();
				temp.add(rows);
				temp.add(cols);
				attack.add(new LinkedList<>(temp));
				break;
			}
			rows = rows + rowDiff;
			cols = cols + colDiff;
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] queens = { { 0, 1 }, { 1, 0 }, { 4, 0 }, { 0, 4 }, { 3, 3 }, { 2, 4 } };
		int[] king = { 0, 0 };
		System.out.println(queensAttacktheKing(queens, king));
	}

}
