package Array_Medium;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

//40

public class CombinationSumII {

	public static List<List<Integer>> combinationSum2(int[] candidates, int target) {
		Arrays.sort(candidates);
		List<List<Integer>> sum = new LinkedList<>();
		combinationSum2(candidates, target, 0, new LinkedList<Integer>(), sum);
		return sum;
	}

	private static void combinationSum2(int[] candidates, int target, int vidx, LinkedList<Integer> temp,
			List<List<Integer>> sum) {

		if (target == 0) {
			sum.add(new LinkedList<>(temp));
			return;
		}

		for (int i = vidx; i < candidates.length; i++) {
			if (i > vidx && candidates[i] == candidates[i - 1]) {
				continue;
			}
			if (target - candidates[i] >= 0) {
				temp.add(candidates[i]);
				combinationSum2(candidates, target - candidates[i], i + 1, temp, sum);
				temp.remove(temp.size() - 1);
			} else {
				return;
			}
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] candidates = { 10, 1, 2, 7, 6, 1, 5 };
		int target = 8;
		System.out.println(combinationSum2(candidates, target));
	}

}
