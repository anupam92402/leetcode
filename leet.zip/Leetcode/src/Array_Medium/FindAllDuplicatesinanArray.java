package Array_Medium;

import java.util.LinkedList;
import java.util.List;

//442

public class FindAllDuplicatesinanArray {

	public static List<Integer> findDuplicates(int[] nums) {
		List<Integer> duplicates = new LinkedList<>();
		for (int i = 0; i < nums.length; i++) {
			int num = Math.abs(nums[i]);
			if (nums[num - 1] < 0) {
				duplicates.add(num);
			} else {
				nums[num - 1] *= -1;
			}
		}
		return duplicates;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 4, 3, 2, 7, 8, 2, 3, 1 };
		System.out.println(findDuplicates(nums));
	}

}
