package Array_Medium;

//75

public class SortColors {

	public static void sortColors(int[] nums) {
		int start = 0, end = nums.length - 1, idx = 0;
		while (idx <= end) {
			if (nums[idx] == 0) {
				nums[idx] = nums[start];
				nums[start++] = 0;
			} else if (nums[idx] == 2) {
				nums[idx] = nums[end];
				nums[end--] = 2;
				idx--;
			}
			idx++;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 2, 0, 2, 1, 1, 0 };
		sortColors(nums);
	}

}
