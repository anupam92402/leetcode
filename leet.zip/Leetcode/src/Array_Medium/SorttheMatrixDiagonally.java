package Array_Medium;

//1329

public class SorttheMatrixDiagonally {

	public static int[][] diagonalSort1(int[][] mat) {
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat[0].length; j++) {
				int k = 1, min = mat[i][j], x = i, y = j;
				while (k + i < mat.length && k + j < mat[0].length) {
					if (mat[i + k][j + k] < min) {
						min = mat[i + k][j + k];
						x = i + k;
						y = j + k;
					}
					k++;
				}
				if (min != mat[i][j]) {
					int temp = mat[i][j];
					mat[i][j] = mat[x][y];
					mat[x][y] = temp;
				}
			}
		}
		return mat;
	}

	public static int[][] diagonalSort2(int[][] mat) {
		int row = mat.length;
		int col = mat[0].length;
		for (int i = 0; i < col; i++) {
			sort(0, i, row, col, mat);
		}
		for (int i = 1; i < row; i++) {
			sort(i, 0, row, col, mat);
		}
		return mat;
	}

	private static void sort(int x, int y, int row, int col, int[][] mat) {
		int[] values = new int[101];
		int r = x;
		int c = y;
		while (x < row && y < col) {
			values[mat[x][y]]++;
			x++;
			y++;
		}

		for (int i = 0; i < 101; i++) {
			if (values[i] > 0) {
				int count = values[i];
				while (count > 0) {
					count--;
					mat[r][c] = i;
					r++;
					c++;
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] mat = { { 3, 3, 1, 1 }, { 2, 2, 1, 2 }, { 1, 1, 1, 2 } };
		int[][] answer = diagonalSort2(mat);
		for (int[] ans : answer) {
			for (int a : ans) {
				System.out.print(a + " ");
			}
			System.out.println();
		}
	}

}
