package Array_Medium;

public class MakeSumDivisiblebyP {

	public static int minSubarray(int[] nums, int p) {
		long sum = 0;
		for (int n : nums) {
			sum += n;
		}
		if (sum % p == 0) {
			return 0;
		}
		int min = Integer.MAX_VALUE, tempSum = 0;
		for (int i = 0; i < nums.length; i++) {
			tempSum = nums[i];
			if ((sum - tempSum) % p == 0) {
				return 1;
			}
			for (int j = i + 1; j < nums.length; j++) {
				tempSum += nums[j];
				if ((sum - tempSum) % p == 0) {
					min = Math.min(min, j - i + 1);
				}
			}
		}
		return min == nums.length ? -1 : min;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 1, 2, 3 };
		int p = 7;
		System.out.println(minSubarray(nums, p));
	}

}
