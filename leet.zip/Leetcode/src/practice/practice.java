package practice;

public class practice {
	static int m, n;
	static char[][] grid;
	static String input;

	public static boolean exist(char[][] board, String word) {
		m = board.length;
		n = board[0].length;
		grid = board;
		input = word;

		for (int i = 0; i < m; i++)
			for (int j = 0; j < n; j++) {
				int l = word.length() - 1;
				if (dfs(l, i, j, new boolean[m][n]))
					return true;
			}

		return false;
	}

	public static boolean dfs(int p, int i, int j, boolean[][] used) {
		if (p < 0)
			return true;

		if (i < 0 || i >= m || j < 0 || j >= n || used[i][j] || grid[i][j] != input.charAt(p))
			return false;

		used[i][j] = true;
		--p;

		return dfs(p, i, j + 1, used) || dfs(p, i + 1, j, used) || dfs(p, i, j - 1, used) || dfs(p, i - 1, j, used);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[][] board = { { 'A', 'B', 'C', 'E' }, { 'S', 'F', 'C', 'S' }, { 'A', 'D', 'E', 'E' } };
		String word = "SEE";
		System.out.println(exist(board, word));
	}

}
