package DP_Easy;

//509

public class FibonacciNumber {

	public static int fib(int n) {
		if (n == 0 || n == 1) {
			return n;
		}
		int a = 1, b = 0;
		for (int i = 2; i <= n; i++) {
			int s = a + b;
			b = a;
			a = s;
		}
		return a;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 3;
		System.out.println(fib(n));
	}

}
