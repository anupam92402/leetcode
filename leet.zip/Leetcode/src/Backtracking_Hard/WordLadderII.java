package Backtracking_Hard;

import java.util.LinkedList;
import java.util.List;

public class WordLadderII {

	static List<List<String>> sequence = new LinkedList<>();
	static LinkedList<String> temp = new LinkedList<>();

	public static List<List<String>> findLadders(String beginWord, String endWord, List<String> wordList) {
		sequence = new LinkedList<>();
		temp = new LinkedList<>();
		if (!wordList.contains(endWord)) {
			return sequence;
		}
		wordList.remove(endWord);
		wordList.add(endWord);
		if (wordList.contains(beginWord)) {
			wordList.remove(beginWord);
		}
		temp.add(beginWord);
		findLadders(endWord, wordList, 0, new boolean[wordList.size()]);
		return sequence;
	}

	private static void findLadders(String endWord, List<String> wordList, int vidx, boolean[] check) {

		if (vidx == wordList.size()) {
			if (sequence.size() == 0 || temp.size() <= sequence.get(sequence.size() - 1).size()) {
				if (sequence.size() != 0 && temp.size() < sequence.get(sequence.size() - 1).size()) {
					sequence = new LinkedList<>();
				}
				sequence.add(new LinkedList<>(temp));
			}
			return;
		}

		for (int i = vidx; i < wordList.size(); i++) {
			String s1 = temp.get(temp.size() - 1);
			String s2 = wordList.get(i);
			if (check(s1, s2) && check[i] == false) {
				check[i] = true;
				temp.add(s2);
				if (i == wordList.size() - 1)
					findLadders(endWord, wordList, wordList.size(), check);
				else
					findLadders(endWord, wordList, 0, check);

				temp.remove(temp.size() - 1);
				check[i] = false;
			}
		}

	}

	public static boolean check(String s1, String s2) {
		int count = 0;
		for (int i = 0; i < s1.length(); i++) {
			if (s1.charAt(i) != s2.charAt(i)) {
				count++;
			}
			if (count == 2) {
				return false;
			}
		}
		return count == 1 ? true : false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String beginWord = "red";
		String endWord = "tax";
		LinkedList<String> wordList = new LinkedList<>();
		wordList.add("ted");
		wordList.add("tex");
		wordList.add("red");
		wordList.add("tax");
		wordList.add("tad");
		wordList.add("den");
		wordList.add("rex");
		wordList.add("pee");
		System.out.println(findLadders(beginWord, endWord, wordList));

	}

}
