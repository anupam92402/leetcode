package LinkedList_Hard;

//25

public class ReverseNodesinkGroup {

	public class ListNode {
		int val;
		ListNode next;

		ListNode() {
		}

		ListNode(int val) {
			this.val = val;
		}

		ListNode(int val, ListNode next) {
			this.val = val;
			this.next = next;
		}
	}

	public ListNode reverseKGroup(ListNode head, int k) {
		ListNode dummyHead = new ListNode(0);
		ListNode dummy = dummyHead;
		dummyHead.next = head;
		ListNode start = dummy;

		while (dummy != null) {

			int count = k;
			while (count != 0 && dummy != null) {
				dummy = dummy.next;
				count--;
			}

			if (dummy == null) {
				return dummyHead.next;
			}

			ListNode end = dummy.next, tail = start.next;
			dummy.next = null;
			start.next = reverseLinkedList(tail);
			tail.next = end;
			start = tail;
			dummy = start;
		}

		return dummyHead.next;
	}

	public ListNode reverseLinkedList(ListNode root) {
		if (root == null || root.next == null) {
			return root;
		}
		ListNode prev = root, curr = root.next;
		prev.next = null;
		while (curr != null) {
			prev = curr;
			curr = curr.next;

			prev.next = root;
			root = prev;
		}
		return root;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
