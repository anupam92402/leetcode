package Array_Easy;

import java.util.HashSet;
import java.util.Set;

//217

public class ContainsDuplicate {

	public static boolean containsDuplicate(int[] nums) {
		Set<Integer> duplicate = new HashSet<>();
		for (int i = 0; i < nums.length; i++) {
			if (duplicate.contains(nums[i])) {
				return true;
			}
			duplicate.add(nums[i]);
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 1, 2, 3, 4 };
		System.out.println(containsDuplicate(nums));
	}

}
