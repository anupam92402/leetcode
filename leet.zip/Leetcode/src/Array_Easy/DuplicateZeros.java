package Array_Easy;

//1089

public class DuplicateZeros {

	public static void duplicateZeros(int[] arr) {
		int idx = 0, i = 0;
		boolean check = false;
		for (i = 0; i < arr.length && idx < arr.length; i++) {
			if (idx == arr.length - 1 && arr[i] == 0) {
				check = true;
				i++;
				idx++;
				break;
			}
			if (arr[i] == 0) {
				idx++;
			}
			idx++;
		}
		i--;
		System.out.println(i);
		for (int j = arr.length - 1; j >= 0; j--) {
			if (check) {
				arr[j] = 0;
				i--;
				check = false;
				continue;
			}
			arr[j] = arr[i];
			if (arr[i] == 0) {
				j--;
				arr[j] = 0;
			}
			i--;
		}
		for (int a : arr) {
			System.out.print(a + " ");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 2, 3 };
		duplicateZeros(arr);
	}

}
