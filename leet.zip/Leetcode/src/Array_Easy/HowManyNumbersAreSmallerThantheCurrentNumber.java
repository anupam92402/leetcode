package Array_Easy;

//1365

public class HowManyNumbersAreSmallerThantheCurrentNumber {

	public static int[] smallerNumbersThanCurrent(int[] nums) {

		int[] freq = new int[101];
		for (int n : nums) {
			freq[n]++;
		}

		int[] smaller = new int[101];
		for (int i = 1; i < 101; i++) {
			smaller[i] = smaller[i - 1] + freq[i - 1];
		}

		for (int i = 0; i < nums.length; i++) {
			nums[i] = smaller[nums[i]];
		}
		return nums;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 7, 7, 7, 7, 7, 7, 7 };
		int[] ans = smallerNumbersThanCurrent(nums);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
