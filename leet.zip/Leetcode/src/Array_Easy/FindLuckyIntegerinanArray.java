package Array_Easy;

//1394

public class FindLuckyIntegerinanArray {

	public static int findLucky(int[] arr) {
		int[] freq = new int[501];
		int ans = -1;
		for (int i = 0; i < arr.length; i++) {
			freq[arr[i]]++;
		}
		for (int i = 500; i >= 0; i--) {
			if (freq[i] == i) {
				ans = i;
				break;
			}
		}
		return ans;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 2, 2, 3, 3, 3 };
		System.out.println(findLucky(arr));
	}

}
