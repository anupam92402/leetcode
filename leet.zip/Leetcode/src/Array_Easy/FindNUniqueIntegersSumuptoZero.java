package Array_Easy;

//1304

public class FindNUniqueIntegersSumuptoZero {

	public static int[] sumZero(int n) {
		int[] result = new int[n];
		for (int i = 0; i < n - 1; i += 2) {
			result[i] = i + 1;
			result[i + 1] = -(i + 1);
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int[] ans = sumZero(n);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
