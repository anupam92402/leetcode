package Array_Easy;

//283

public class MoveZeroes {

	public static void moveZeroes(int[] nums) {
		int i = 0, li = 0;
		for (i = 0; i < nums.length; i++) {
			if (nums[i] != 0) {
				nums[li++] = nums[i];
			}
		}
		for (i = li; i < nums.length; i++) {
			nums[i] = 0;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 0, 1, 0, 3, 12 };
		moveZeroes(nums);
	}

}
