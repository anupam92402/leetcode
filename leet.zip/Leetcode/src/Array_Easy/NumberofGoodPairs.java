package Array_Easy;

//1512

public class NumberofGoodPairs {

	public static int numIdenticalPairs(int[] nums) {
		int[] pairs = new int[101];
		for (int n : nums) {
			pairs[n]++;
		}
		int goodPairs = 0;
		for (int p : pairs) {
			goodPairs += (p * (p - 1)) / 2;
		}
		return goodPairs;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 1, 1 };
		System.out.println(numIdenticalPairs(nums));
	}

}
