package Array_Easy;

import java.util.HashSet;
import java.util.Set;

//1346

public class CheckIfNandItsDoubleExist {

	public static boolean checkIfExist(int[] arr) {
		Set<Integer> doubleExists = new HashSet<>();
		for (int a : arr) {
			if (doubleExists.contains(a * 2) || (a % 2 == 0 && doubleExists.contains(a / 2))) {
				return true;
			}
			doubleExists.add(a);
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 7, 1, 14, 11 };
		System.out.println(checkIfExist(arr));
	}

}
