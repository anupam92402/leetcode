package Array_Easy;

//1732

public class FindtheHighestAltitude {

	public static int largestAltitude(int[] gain) {
		int max = 0;
		int altitude = 0;
		for (int g : gain) {
			altitude += g;
			max = Math.max(altitude, max);
		}
		return max;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] gain = { -4, -3, -2, -1, 4, 3, 2 };
		System.out.println(largestAltitude(gain));
	}

}
