package Array_Easy;

//821

public class ShortestDistancetoaCharacter {

	public static int[] shortestToChar(String s, char c) {
		int min = -1000000;
		int[] distance = new int[s.length()];
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == c) {
				min = i;
			}
			distance[i] = i - min;
		}
		min = 1000000;
		for (int i = s.length() - 1; i >= 0; i--) {
			if (s.charAt(i) == c) {
				min = i;
			}
			distance[i] = Math.min(Math.abs(distance[i]), min - i);
		}
		return distance;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "loveleetcode";
		char ch = 'e';
		int[] ans = shortestToChar(s, ch);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
