package Array_Easy;

//1337

public class TheKWeakestRowsinaMatrix {

	static class Pair {
		int val;
		int idx;

		public Pair(int val, int idx) {
			this.val = val;
			this.idx = idx;
		}
	}

	public static int[] kWeakestRows1(int[][] mat, int k) {
		Pair[] soilders = new Pair[mat.length];
		for (int i = 0; i < mat.length; i++) {
			int count = 0;
			for (int j = 0; j < mat[0].length; j++) {
				if (mat[i][j] == 0) {
					break;
				}
				count++;
			}
			Pair p = new Pair(count, i);
			soilders[i] = p;
		}

		for (int i = 0; i < soilders.length - 1; i++) {
			for (int j = i + 1; j < soilders.length; j++) {
				if (soilders[i].val > soilders[j].val
						|| (soilders[i].val == soilders[j].val && soilders[i].idx > soilders[j].idx)) {
					Pair p = soilders[i];
					soilders[i] = soilders[j];
					soilders[j] = p;
				}
			}
		}

		int[] weakest = new int[k];
		for (int i = 0; i < k; i++) {
			weakest[i] = soilders[i].idx;
		}

		return weakest;
	}

	public static int[] kWeakestRows2(int[][] mat, int k) {

		int n = mat.length;
		int idx = 0;
		int[] res = new int[n];

		for (int row = 0; row < n; row++) {
			int pos = binarySearch(mat[row]);
			res[idx++] = pos + 1;
		}

		int[] ans = new int[k];

		for (int i = 0; i < k; i++) {
			ans[i] = findMin(res);
		}

		return ans;
	}

	private static int binarySearch(int[] arr) {

		int low = 0;
		int high = arr.length;

		while (low <= high) {
			int mid = low + (high - low) / 2;

			if (mid == arr.length) {
				return mid;
			}
			if (arr[mid] == 0) {
				high = mid - 1;
			} else {
				low = mid + 1;
			}
		}

		return arr[low] == 0 ? high : -1;
	}

	private static int findMin(int[] arr) {

		int min = Integer.MAX_VALUE;
		int idx = -1;

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] != -1 && arr[i] < min) {
				min = arr[i];
				idx = i;
			}
		}

		arr[idx] = -1;
		return idx;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] mat = { { 1, 0 }, { 1, 0 }, { 1, 0 }, { 1, 1 } };
		int k = 4;
		int[] ans = kWeakestRows2(mat, k);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
