package Array_Easy;

import java.util.LinkedList;
import java.util.List;

//1431

public class KidsWiththeGreatestNumberofCandies {

	public static List<Boolean> kidsWithCandies(int[] candies, int extraCandies) {
		List<Boolean> candy = new LinkedList<>();
		int max = 0;
		for (int c : candies) {
			max = Math.max(max, c);
		}
		for (int c : candies) {
			if (c + extraCandies >= max) {
				candy.add(true);
			} else {
				candy.add(false);
			}
		}
		return candy;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] candies = { 2, 3, 5, 1, 3 };
		int extraCandies = 3;
		System.out.println(kidsWithCandies(candies, extraCandies));
	}

}
