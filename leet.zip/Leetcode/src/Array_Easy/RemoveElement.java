package Array_Easy;

//27

public class RemoveElement {

	public static int removeElement(int[] nums, int val) {
		int li = 0;// last index
		for (int i = 0; i < nums.length; i++) {
			if (nums[i] != val) {
				nums[li++] = nums[i];
			}
		}
		return li;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 0, 1, 2, 2, 3, 0, 4, 2 };
		int val = 2;
		int ans = removeElement(nums, val);
		for (int i = 0; i < ans; i++) {
			System.out.print(nums[i] + " ");
		}
	}

}
