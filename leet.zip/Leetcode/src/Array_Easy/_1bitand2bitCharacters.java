package Array_Easy;

//717

public class _1bitand2bitCharacters {

	public static boolean isOneBitCharacter(int[] bits) {
		int i = 0;
		boolean ans = true;
		while (i < bits.length) {
			if (bits[i] == 0) {
				i++;
				ans = true;
			} else {
				i += 2;
				ans = false;
			}
		}
		return ans;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] bits = { 1, 0, 0 };
		System.out.println(isOneBitCharacter(bits));
	}

}
