package Array_Easy;

import java.util.HashMap;

//594

public class LongestHarmoniousSubsequence {

	public static int findLHS(int[] nums) {
		HashMap<Integer, Integer> subsequence = new HashMap<>();

		for (int i = 0; i < nums.length; i++) {
			if (subsequence.containsKey(nums[i])) {
				int of = subsequence.get(nums[i]);
				subsequence.put(nums[i], of + 1);
			} else {
				subsequence.put(nums[i], 1);
			}
		}

		int lhs = 0;// Longest Harmonious Subsequence

		for (int key : subsequence.keySet()) {
			if (subsequence.containsKey(key + 1)) {
				lhs = Math.max(lhs, subsequence.get(key) + subsequence.get(key + 1));
			}
		}
		return lhs;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 1, 3, 2, 2, 5, 2, 3, 7 };
		System.out.println(findLHS(nums));
	}

}
