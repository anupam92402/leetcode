package Array_Easy;

//1470

public class ShuffletheArray {

	public static int[] shuffle(int[] nums, int n) {
		int[] shuffle = new int[nums.length];
		int j = 0;
		for (int i = 0; i < nums.length / 2; i++) {
			shuffle[j++] = nums[i];
			shuffle[j++] = nums[i + n];
		}
		return shuffle;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 2, 5, 1, 3, 4, 7 };
		int n = 3;
		int[] ans = shuffle(nums, n);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
