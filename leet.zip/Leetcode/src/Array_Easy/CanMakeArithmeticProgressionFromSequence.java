package Array_Easy;

import java.util.HashSet;

//1502

public class CanMakeArithmeticProgressionFromSequence {

	public static boolean canMakeArithmeticProgression(int[] arr) {
		int n = arr.length;
		if (n <= 1) {
			return true;
		}
		HashSet<Integer> ap = new HashSet<>();
		int min = Integer.MAX_VALUE;
		int max = Integer.MIN_VALUE;
		for (int val : arr) {
			min = Math.min(val, min);
			max = Math.max(val, max);
			ap.add(val);
		}
		int d = (max - min) / (n - 1);
		for (int i = 0; i < n; i++) {
			int ai = min + i * d;
			if (!ap.contains(ai)) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 3, 5, 1 };
		System.out.println(canMakeArithmeticProgression(arr));
	}

}
