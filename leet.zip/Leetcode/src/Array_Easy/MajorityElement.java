package Array_Easy;

//169

public class MajorityElement {

	public static int majorityElement(int[] nums) {
		int i = 0, count = 0, num = 0;
		for (i = 0; i < nums.length; i++) {
			if (count == 0) {
				num = nums[i];
			}
			count += num == nums[i] ? 1 : -1;
		}
		return num;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 2, 2, 1, 1, 1, 2, 2 };
		System.out.println(majorityElement(nums));
	}

}
