package Array_Easy;

import java.util.ArrayList;

//1389F

public class CreateTargetArrayintheGivenOrder {

	public static int[] createTargetArray(int[] nums, int[] index) {
		ArrayList<Integer> target = new ArrayList<>();
		for (int i = 0; i < nums.length; i++) {
			target.add(index[i], nums[i]);
		}
		int[] targetArray = new int[target.size()];
		for (int i = 0; i < nums.length; i++) {
			targetArray[i] = target.get(i);
		}
		return targetArray;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 0, 1, 2, 3, 4 };
		int[] index = { 0, 1, 2, 2, 1 };
		int[] ans = createTargetArray(nums, index);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
