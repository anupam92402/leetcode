package Array_Easy;

//121

public class BestTimetoBuyandSellStock {

	public static int maxProfit(int[] prices) {
		int minprice = prices[0];
		int maxprofit = 0;
		for (int i = 1; i < prices.length; i++) {
			if (prices[i] - minprice > maxprofit)
				maxprofit = prices[i] - minprice;
			if (prices[i] < minprice)
				minprice = prices[i];
		}
		return maxprofit;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] prices = { 7, 1, 5, 3, 6, 4 };
		System.out.println(maxProfit(prices));
	}

}
