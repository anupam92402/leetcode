package Array_Easy;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

//1773

public class CountItemsMatchingaRule {

	private static final Map<String, Integer> rule = Map.of("type", 0, "color", 1, "name", 2);

	public static int countMatches(List<List<String>> items, String ruleKey, String ruleValue) {
		int cnt = 0, index = rule.get(ruleKey);
		for (List<String> item : items) {
			if (item.get(index).equals(ruleValue)) {
				++cnt;
			}
		}
		return cnt;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<List<String>> items = new LinkedList<>();
		LinkedList<String> temp = new LinkedList<>();
		temp.add("phone");
		temp.add("blue");
		temp.add("pixel");
		items.add(new LinkedList<>(temp));

		temp = new LinkedList<>();
		temp.add("computer");
		temp.add("silver");
		temp.add("lenovo");
		items.add(new LinkedList<>(temp));

		temp = new LinkedList<>();
		temp.add("phone");
		temp.add("gold");
		temp.add("iphone");
		items.add(new LinkedList<>(temp));

		String ruleKey = "color";
		String ruleValue = "silver";

		System.out.println(countMatches(items, ruleKey, ruleValue));
	}

}
