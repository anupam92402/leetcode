package Array_Easy;

//1313

public class DecompressRunLengthEncodedList {

	public static int[] decompressRLElist(int[] nums) {
		int length = 0, idx = 0;
		for (int i = 0; i < nums.length; i += 2) {
			length += nums[i];
		}
		int[] decompress = new int[length];
		for (int i = 0; i < nums.length; i = i + 2) {
			int freq = nums[i];
			int val = nums[i + 1];
			idx += construct(freq, val, decompress, idx);
		}

		return decompress;
	}

	private static int construct(int freq, int val, int[] decompress, int idx) {
		int i;
		for (i = 0; i < freq; i++) {
			decompress[idx++] = val;
		}
		return i;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = {55,11,70,26,62,64 };
		int[] ans = decompressRLElist(nums);
		for (int a : ans) {
			System.out.printf(a + " ");
		}
	}

}
