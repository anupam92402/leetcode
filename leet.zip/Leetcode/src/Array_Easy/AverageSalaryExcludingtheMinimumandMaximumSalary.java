package Array_Easy;

//1491

public class AverageSalaryExcludingtheMinimumandMaximumSalary {

	public static double average(int[] salary) {
		double avg = 0;
		int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
		for (int s : salary) {
			avg += s;
			min = Math.min(min, s);
			max = Math.max(s, max);
		}
		avg = avg - min - max;
		return avg / (salary.length - 2);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] salary = { 4000, 3000, 1000, 2000 };
		System.out.println(average(salary));
	}

}
