package Array_Easy;

//1252

public class CellswithOddValuesinaMatrix {

	public static int oddCells(int m, int n, int[][] indices) {
		int[] rows = new int[m];
		int[] cols = new int[n];
		for (int i = 0; i < indices.length; i++) {
			rows[indices[i][0]]++;
			cols[indices[i][1]]++;
		}
		int oddValues = 0;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				if ((rows[i] + cols[j]) % 2 != 0) {
					oddValues++;
				}
			}
		}
		return oddValues;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m = 48;
		int n = 37;
		int[][] indices = { { 40, 5 } };
		System.out.println(oddCells(m, n, indices));
	}

}
