package Array_Easy;

//26

public class RemoveDuplicatesfromSortedArray {

	public static int removeDuplicates(int[] nums) {
		int li = 0;// last index
		for (int i = 0; i < nums.length; i++) {
			if (i == 0 || nums[i] != nums[i - 1]) {
				nums[li++] = nums[i];
			}
		}
		return li;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 0, 0, 1, 1, 1, 2, 2, 3, 3, 4, 4 };
		int ans = removeDuplicates(nums);
		for (int i = 0; i < ans; i++) {
			System.out.print(nums[i] + " ");
		}
	}

}
