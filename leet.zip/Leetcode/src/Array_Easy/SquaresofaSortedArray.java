package Array_Easy;

//977

public class SquaresofaSortedArray {

	public static int[] sortedSquares(int[] nums) {
		int n = nums.length;
		int[] result = new int[n];
		int i = 0, j = n - 1;
		for (int idx = n - 1; idx >= 0; idx--) {
			if (Math.abs(nums[i]) > Math.abs(nums[j])) {
				result[idx] = nums[i] * nums[i];
				i++;
			} else {
				result[idx] = nums[j] * nums[j];
				j--;
			}
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { -4, -1, 0, 3, 10 };
		int[] ans = sortedSquares(nums);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
