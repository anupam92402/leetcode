package Array_Easy;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

//989

public class AddtoArrayFormofInteger {

	public static List<Integer> addToArrayForm(int[] num, int k) {
		List<Integer> add = new LinkedList<>();
		int n = num.length;
		while (n-- > 0 || k > 0) {
			if (n >= 0)
				k += num[n];
			add.add(k % 10);
			k /= 10;
		}
		Collections.reverse(add);
		return add;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = { 2, 1, 5 };
		int k = 806;
		System.out.println(addToArrayForm(num, k));
	}

}
