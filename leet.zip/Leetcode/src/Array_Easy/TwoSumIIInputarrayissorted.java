package Array_Easy;

import java.util.HashMap;

//167

public class TwoSumIIInputarrayissorted {

	// using hashmap
	public static int[] twoSum1(int[] numbers, int target) {
		HashMap<Integer, Integer> map = new HashMap<>();
		for (int i = 0; i < numbers.length; i++) {
			if (map.containsKey(target - numbers[i]) && map.get(target - numbers[i]) != i) {
				if (numbers[i] >= numbers[map.get(target - numbers[i])]) {
					return new int[] { map.get(target - numbers[i]) + 1, i + 1 };
				} else {
					return new int[] { i + 1, map.get(target - numbers[i]) + 1 };
				}
			}
			map.put(numbers[i], i);
		}
		throw new IllegalArgumentException("no matches found");
	}

	// Optimized binary search
	public static int[] twoSum2(int[] numbers, int target) {
		int[] res = new int[2];
		int lo = 0, hi = numbers.length - 1;

		while (lo < hi) {
			int sum = numbers[lo] + numbers[hi];
			if (sum == target) {
				return new int[] { lo + 1, hi + 1 };
			}
			if (sum < target)
				lo++;
			else
				hi--;
		}

		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] numbers = { 0, 0, 3, 4, };
		int target = 0;
		int[] ans = twoSum1(numbers, target);
		System.out.println(ans[0] + " " + ans[1]);
	}

}
