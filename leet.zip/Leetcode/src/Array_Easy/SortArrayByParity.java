package Array_Easy;

//905

public class SortArrayByParity {

	public static int[] sortArrayByParity(int[] nums) {
		int i = 0, j = nums.length - 1;
		while (i < j) {
			if (nums[i] % 2 > nums[j] % 2) {
				int tmp = nums[i];
				nums[i] = nums[j];
				nums[j] = tmp;
			}

			if (nums[i] % 2 == 0)
				i++;
			if (nums[j] % 2 == 1)
				j--;
		}

		return nums;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 4, 2, 5, 7 };
		int[] ans = sortArrayByParity(nums);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
