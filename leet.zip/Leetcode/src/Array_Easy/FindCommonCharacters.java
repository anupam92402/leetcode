package Array_Easy;

import java.util.LinkedList;
import java.util.List;

public class FindCommonCharacters {

	public static List<String> commonChars(String[] words) {
		int[] alphabets = new int[26];
		for (int i = 0; i < words.length; i++) {
			for (int j = 0; j < words[i].length(); j++) {
				char ch = words[i].charAt(j);
				if (alphabets[ch - 'a'] == i) {
					alphabets[ch - 'a']++;
				}
			}
		}
		List<String> commonChar = new LinkedList<>();
		for (int i = 0; i < alphabets.length; i++) {
			if (alphabets[i] == words.length) {
				int c = 97 + i;
				char ch = (char) c;
				commonChar.add(ch + "");
			}
		}
		return commonChar;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] words = { "cool","lock","cook"};
		System.out.println(commonChars(words));
	}

}
