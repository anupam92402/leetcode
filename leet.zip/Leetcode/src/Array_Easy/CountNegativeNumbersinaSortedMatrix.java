package Array_Easy;

//1351

public class CountNegativeNumbersinaSortedMatrix {

	public static int countNegatives(int[][] grid) {
		int count = 0;
		for (int[] row : grid) {
			count += row.length - binSearch(row);
		}

		return count;
	}

	private static int binSearch(int[] arr) {
		int left = 0, right = arr.length - 1;
		int mid;

		while (left <= right) {
			mid = (right - left) / 2 + left;

			if (arr[mid] <= -1)
				right = mid - 1;
			else
				left = mid + 1;
		}

		return left;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] grid = { { 4, 3, 2, -1 }, { 3, 2, 1, -1 }, { 1, 1, -1, -2 }, { -1, -1, -2, -3 } };
		System.out.println(countNegatives(grid));
	}

}
