package Array_Easy;

//1464

public class MaximumProductofTwoElementsinanArray {

	public static int maxProduct(int[] nums) {
		int m = Integer.MIN_VALUE, n = m;
		for (int num : nums) {
			if (num >= m) {
				n = m;
				m = num;
			} else if (num > n) {
				n = num;
			}
		}
		return (m - 1) * (n - 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 3, 4, 5, 2 };
		System.out.println(maxProduct(nums));
	}

}
