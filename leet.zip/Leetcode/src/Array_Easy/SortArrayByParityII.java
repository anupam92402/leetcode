package Array_Easy;

//922

public class SortArrayByParityII {
	public static int[] sortArrayByParityII(int[] nums) {
		int even = 0, odd = 1;
		while (true) {
			while (even < nums.length && nums[even] % 2 == 0)
				even += 2;
			while (odd < nums.length && nums[odd] % 2 != 0)
				odd += 2;
			if (odd >= nums.length || even >= nums.length)
				return nums;

			int temp = nums[even];
			nums[even] = nums[odd];
			nums[odd] = temp;
		}
	}

	public static void main(String[] args) {
		int[] nums = { 4, 2, 5, 7 };
		int[] ans = sortArrayByParityII(nums);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
