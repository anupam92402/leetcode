package Array_Easy;

import java.util.stream.IntStream;

//1742

public class MaximumNumberofBallsinaBox {

	public static int countBalls(int lowLimit, int highLimit) {
		int[] box = new int[46];
		int lo = lowLimit, id = 0;
		while (lo > 0) { // compute box id for lowLimit.
			id += lo % 10;
			lo /= 10;
		}
		++box[id];
		for (int i = lowLimit + 1; i <= highLimit; ++i) { // compute all other box ids.
			int digits = i;
			while (digits % 10 == 0) { // for ball numbers with trailing 0's, decrease 9 for each 0.
				id -= 9;
				digits /= 10;
			}
			++box[++id];
		}
		return IntStream.of(box).max().getAsInt();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int lowLimit = 19, highLimit = 28;
		System.out.println(countBalls(lowLimit, highLimit));
	}

}
