package Array_Easy;

//1480

public class RunningSumof1dArray {

	public static int[] runningSum(int[] nums) {
		for (int i = 1; i < nums.length; i++) {
			nums[i] += nums[i - 1];
		}
		return nums;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 1, 2, 3, 4 };
		int[] ans = runningSum(nums);
		for (int a : ans) {
			System.out.print(a + " ");
		}
	}

}
