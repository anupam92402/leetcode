package Array_Easy;

//268

public class MissingNumber {

	public static int missingNumber(int[] nums) {
		int expectedSum = nums.length * (nums.length + 1) / 2;
		int actualSum = 0;
		for (int num : nums)
			actualSum += num;
		return expectedSum - actualSum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] nums = { 3, 0, 1 };
		System.out.println(missingNumber(nums));
	}

}
