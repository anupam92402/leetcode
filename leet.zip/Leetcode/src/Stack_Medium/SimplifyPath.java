package Stack_Medium;

import java.util.Stack;

//71

public class SimplifyPath {

	public static String simplifyPath(String path) {
		String[] pathComponents = path.split("/");
		Stack<String> stack = new Stack<>();
		for (String p : pathComponents) {
			if (p.equals(".") || p.isEmpty())
				continue;
			else if (p.equals("..")) {
				if (!stack.isEmpty())
					stack.pop();
			} else
				stack.push(p);
		}
		StringBuilder sb = new StringBuilder();
		for (String dir : stack) {
			sb.append("/");
			sb.append(dir);
		}
		return sb.length() == 0 ? "/" : sb.toString();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String path = "/home//foo/";
		System.out.println(simplifyPath(path));
	}

}
