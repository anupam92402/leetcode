package Math_Easy;

//1486

public class XOROperationinanArray {
	public static int xorOperation(int n, int start) {
		int result = 0;
		for (int i = 0; i < n; i++) {
			result ^= (start + (2 * i));
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int start = 0;
		System.out.println(xorOperation(n, start));
	}

}
