package Math_Medium;

//670

public class MaximumSwap {

	public static int maximumSwap(int num) {
		char[] digits = Integer.toString(num).toCharArray();

		int[] lastOccurance = new int[10];
		for (int i = 0; i < digits.length; i++) {
			lastOccurance[digits[i] - '0'] = i;
		}

		for (int i = 0; i < digits.length; i++) {
			for (int k = 9; k > digits[i] - '0'; k--) {
				if (lastOccurance[k] > i) {
					char temp = digits[i];
					digits[i] = digits[lastOccurance[k]];
					digits[lastOccurance[k]] = temp;
					return Integer.valueOf(new String(digits));
				}
			}
		}

		return num;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 99793;
		System.out.println(maximumSwap(num));
	}

}
