package BitManipulation_Easy;

//1342

public class NumberofStepstoReduceaNumbertoZero {

	public static int numberOfSteps(int num) {
		if (num == 0)
			return 0;
		int res = 0;
		while (num != 0) {
			res += (num & 1) == 1 ? 2 : 1;
			num >>= 1;
		}
		return res - 1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 4;
		System.out.println(numberOfSteps(num));
	}

}
