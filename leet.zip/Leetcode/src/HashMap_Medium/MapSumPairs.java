package HashMap_Medium;

import java.util.ArrayList;
import java.util.HashMap;

public class MapSumPairs {

	HashMap<String, Integer> pairSum;
	HashMap<Character, ArrayList<String>> prefixSum;

	public MapSumPairs() {
		pairSum = new HashMap<>();
		prefixSum = new HashMap<>();
	}

	public void insert(String key, int val) {
		if (!pairSum.containsKey(key)) {
			if (prefixSum.containsKey(key.charAt(0))) {
				ArrayList<String> al = prefixSum.get(key.charAt(0));
				al.add(key);
				prefixSum.put(key.charAt(0), al);
			} else {
				ArrayList<String> al = new ArrayList<>();
				al.add(key);
				prefixSum.put(key.charAt(0), al);
			}
		}
		pairSum.put(key, val);
	}

	public int sum(String prefix) {
		int sum = 0;
		if (prefixSum.containsKey(prefix.charAt(0))) {
			ArrayList<String> al = prefixSum.get(prefix.charAt(0));
			for (int i = 0; i < al.size(); i++) {
				if (al.get(i).startsWith(prefix)) {
					sum += pairSum.get(al.get(i));
				}
			}
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MapSumPairs msp = new MapSumPairs();
		msp.insert("apple", 3);
		System.out.println(msp.sum("ap"));
		msp.insert("app", 2);
		msp.insert("apple", 2);
		System.out.println(msp.sum("ap"));
	}

}
